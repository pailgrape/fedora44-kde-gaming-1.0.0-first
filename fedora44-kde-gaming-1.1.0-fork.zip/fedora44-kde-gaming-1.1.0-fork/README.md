# FIRST-FORK 1.1.0

Fork of fedora44-kde-gaming-1.0.0-first. Same Fedora 44 KDE Plasma target.
Adds the after-reboot session script, NTSYNC load, GameMode user service,
Plasma adaptive sync through kwriteconfig6, and a Desktop Steam shortcut.

Run from this directory:

```bash
chmod +x install.sh bin/*.sh
./bin/fedora44-kde-gaming-setup.sh --dry-run
./bin/fedora44-kde-gaming-setup.sh
```

After reboot:

```bash
./bin/plasma-game-session.sh
```

Desktop icon is copied by `./install.sh` to ~/Desktop/Steam-Gaming.desktop.
